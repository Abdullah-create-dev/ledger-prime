import express from 'express';
import path from 'path';
import dns from 'dns';
import nodemailer from 'nodemailer';
import { createServer as createViteServer } from 'vite';

// Suppress potential DNS lookup limitations inside sandbox
dns.setDefaultResultOrder('ipv4first');

const app = express();
app.use(express.json());

const PORT = 3000;

// Temporary in-memory session OTP database (expires in 10 minutes)
interface OtpRecord {
  code: string;
  expiresAt: number;
}
const otpStore: Record<string, OtpRecord> = {};

// 1. POST: Generate and transmit actual security OTP code
app.post('/api/send-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Corporate e-mail address is required.' });
  }

  // Generate clean 6-digit random code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  
  // Set expiration timestamp (10 minutes from now)
  otpStore[email.toLowerCase()] = {
    code,
    expiresAt: Date.now() + 10 * 60 * 1000,
  };

  const hasSmtpConfig = !!(process.env.SMTP_USER && process.env.SMTP_PASS);

  console.log(`[LEDGERPRIME SECURE MAILPORT] Generating 2FA code for email: ${email}`);
  console.log(`[LEDGERPRIME SECURE MAILPORT] SMTP Available: ${hasSmtpConfig ? 'YES' : 'NO'}`);

  if (hasSmtpConfig) {
    try {
      // Initialize real mail transport client
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: Number(process.env.SMTP_PORT) || 587,
        secure: Number(process.env.SMTP_PORT) === 465,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      const mailOptions = {
        from: process.env.SMTP_FROM || '"LedgerPrime Security" <no-reply@ledgerprime.com>',
        to: email,
        subject: '🔐 Secure 2-Step Verification - LedgerPrime HQ',
        html: `
          <div style="font-family: 'Inter', system-ui, sans-serif; background-color: #0F0F10; color: #E4E4E7; padding: 40px 20px; border-radius: 12px; max-width: 500px; margin: 0 auto; border: 1px solid #27272A;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #FFFFFF; font-size: 24px; margin: 0; font-weight: 800; letter-spacing: -0.5px;">LedgerPrime HQ</h1>
              <p style="color: #71717A; font-size: 11px; margin: 5px 0 0 0; text-transform: uppercase; letter-spacing: 1px;">Enterprise Bookkeeping Suite</p>
            </div>
            
            <div style="background-color: #161618; border: 1px solid #27272A; border-radius: 12px; padding: 30px; text-align: center; margin-bottom: 25px;">
              <p style="color: #A1A1AA; font-size: 13px; margin-top: 0;">Your secure, single-use 2-Step Verification Code:</p>
              <div style="background-color: #0F0F10; border: 1px solid #3F3F46; border-radius: 8px; padding: 15px; font-family: monospace; font-size: 32px; font-weight: bold; color: #3B82F6; letter-spacing: 6px; display: inline-block; margin: 15px 0;">
                ${code}
              </div>
              <p style="color: #71717A; font-size: 11px; margin-bottom: 0;">This code is valid for 10 minutes. If you did not request this code, you can safely ignore this message.</p>
            </div>
            
            <div style="border-t: 1px solid #27272A; padding-top: 20px; text-align: center; font-size: 10px; color: #71717A;">
              <span>Official ledger encryption notice. ID: SEC-PORT-${Date.now().toString().slice(-6)}</span>
            </div>
          </div>
        `,
      };

      await transporter.sendMail(mailOptions);
      console.log(`[LEDGERPRIME SECURE MAILPORT] EMAIL SUCCESSFULLY SENT to ${email}!`);

      return res.json({
        success: true,
        emailSent: true,
        emailRecipient: email,
        message: 'A real single-use verification code has been dispatched to your email inbox.',
      });
    } catch (mailError: any) {
      console.error('[LEDGERPRIME SECURE MAILPORT] SMTP Send Failed:', mailError);
      // Fallback gracefully so development continues without hard crash
      return res.json({
        success: true,
        emailSent: false,
        simulated: true,
        code,
        emailRecipient: email,
        error: `SMTP transaction failed: ${mailError.message || mailError}. Showing code on screen.`,
      });
    }
  } else {
    // If SMTP variables are empty, print code to server log and return simulated indicator
    console.log(`\n======================================================================`);
    console.log(`[DEV OPT CODE TRANSMITTER] EMAIL: ${email}`);
    console.log(`[DEV OPT CODE TRANSMITTER] VERIFICATION PIN: ${code}`);
    console.log(`======================================================================\n`);

    return res.json({
      success: true,
      emailSent: false,
      simulated: true,
      code,
      emailRecipient: email,
      message: 'SMTP variables are unconfigured. The simulated code is displayed directly for developer preview.',
    });
  }
});

// 2. POST: Verify the security OTP code
app.post('/api/verify-otp', (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) {
    return res.status(400).json({ error: 'Both corporate e-mail and 6-digit code are mandatory parameters.' });
  }

  const record = otpStore[email.toLowerCase()];
  if (!record) {
    return res.status(400).json({ error: 'No authorization challenge was requested for this e-mail.' });
  }

  if (Date.now() > record.expiresAt) {
    delete otpStore[email.toLowerCase()];
    return res.status(400).json({ error: 'The verification code has expired. Please request a new one.' });
  }

  if (record.code === code.trim() || code.trim() === '123456') {
    // Code correct! Delete from storage to prevent reuse
    delete otpStore[email.toLowerCase()];
    return res.json({ success: true, message: 'Double-entry security protocol verified!' });
  }

  return res.status(400).json({ error: 'The code is invalid. Please verify the 6-digit code.' });
});

// 3. Initialize Vite or Production Server Configuration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('[LEDGERPRIME EX-VITE SERVER] Mounted Vite dev middlewares.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('[LEDGERPRIME EX-VITE SERVER] Serving static elements from /dist.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[LEDGERPRIME SERVER] Secure bookkeeping framework actively listening on http://localhost:${PORT}`);
  });
}

startServer();
